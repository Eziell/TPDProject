USE [ngLigaRecord1718]
GO

declare @season nchar(7)
select @season = '2017/18'


INSERT INTO [ngLigaRecord].[dbo].[tpd_team_round]
           (season, [id_team]
           ,[order_round]
           ,[team_name]
           ,[team_points_round]
           ,[team_points_total]
           ,[team_rank_round]
           ,[team_rank_total]
           ,[team_value])
 select distinct @season, t.id
           ,tr.id_round
           ,t.name
           ,tr.points_round
           ,tr.points_total
           ,tr.rank_round
           ,tr.rank_total
           ,sum(pr.value)
from [ngLigaRecord].[dbo].[tpd_team] t with (nolock)
inner join [dbo].[ng_cache_team_round] tr with (nolock) on t.id = tr.id_team 
inner join ng_cache_player_team_round ptr with (nolock) on ptr.id_team = tr.id_team and ptr.id_round = tr.id_round and ((ptr.is_playing = 1 and [id_player_bench_substitution] = 0) or (ptr.is_benched = 1 and [id_player_bench_substitution] > 0))
inner join ng_cache_player_round pr with (nolock) on pr.id_player = ptr.id_player and pr.id_round = ptr.id_round
inner join ng_team_league_private tlp with (nolock) on tlp.id_team = t.id and tlp.status = 1 and tlp.is_valid = 1
inner join [ngLigaRecord].[dbo].tpd_league l with (nolock) on l.season = @season and l.id = tlp.id_league
where t.season = @season
group by t.id
           ,tr.id_round
           ,t.name
           ,tr.points_round
           ,tr.points_total
           ,tr.rank_round
           ,tr.rank_total

GO


