USE [ngLigaRecord1415]
GO

declare @season nchar(7)
select @season = '2014/15'


INSERT INTO [ngLigaRecord].[dbo].[tpd_user_logins]
           ([season]
           ,[id_user]
	   ,[date]
           ,[logins])
select @season
           ,u.id
	   ,convert(varchar(10), ul.timestamp, 21)
           ,count(ul.id)
from  ng_user u1 with (nolock) 
inner join [ngLigaRecord].[dbo].tpd_user u with (nolock) on u1.email = u.email
inner join ng_user_login ul with (nolock) on ul.id_user = u1.id

group by u.id, convert(varchar(10), ul.timestamp, 21)
 




