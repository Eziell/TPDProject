USE [ngLigaRecord]
GO

INSERT INTO [dbo].[tpd_round]
           ([order]
		   ,[start_date]
           ,[end_date]
           ,[publish_date])
select r.[id]
	   , r2.date_end_bets
       , r.[date_end_bets], r.[date_publish]
from ng_round r with (nolock)
inner join ng_round r2 with (nolock) on r2.id = case when r.id = 1 then -1 else r.id - 1 end
where r.is_pre_season = 0
GO


