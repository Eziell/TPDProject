USE [ngLigaRecord]
GO

INSERT INTO [dbo].[tpd_user]
           ([id]
           ,[nickname]
		   ,[address]
           ,[birthdate]
           ,[agegroup]
           ,[gender]
           ,[club]
           ,[region]
           ,[startdate]
           ,[premiumdate])
select distinct u.[id]
           ,u.[nickname]
		   ,u.[address]
           ,u.[birthdate]
           ,case when u.birthdate >= '2004-06-01' then '-15'
		    else case when u.birthdate >= '1995-06-01' then '15-24'
			else case when u.birthdate >= '1985-06-01' then '25-34'
			else case when u.birthdate >= '1975-06-01' then '35-44'
			else case when u.birthdate >= '1965-06-01' then '45-54'
			else case when u.birthdate >= '1955-06-01' then '55-64'
			else '+64' end end end end end end
           ,case when u.[id_gender] = 0 then 'Masculino' else 'Feminino' end
           ,c.name
           ,r.name
           ,u2015.date_start
from ng_user u with (nolock)
inner join ng_team t with (nolock) on t.id_user = u.id
inner join ng_team_league_private tlp with (nolock) on tlp.id_team = t.id and tlp.status = 1 and tlp.is_valid = 1

inner join [dbo].[ng_user_20172018] u2018 with (nolock) on u2018.email = u.email
inner join [dbo].[ng_user_20162017] u2017 with (nolock) on u2017.email = u.email
inner join [dbo].[ng_user_20152016] u2016 with (nolock) on u2016.email = u.email
inner join [dbo].[ng_user_20142015] u2015 with (nolock) on u2015.email = u.email

left join ng_r_club c on c.id = u.id_club
left join ng_r_region r on r.id = u.id_region
left join  dbo.[ng_custom_rules_league_team_cache_round] cr on cr.id_league = tlp.id_league
where cr.id is null and u.nickname != ''

GO


