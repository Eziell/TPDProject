USE [ngLigaRecord1718]
GO

declare @season nchar(7)
select @season = '2017/18'


INSERT INTO [ngLigaRecord].[dbo].[tpd_team]
           (season, [id]
           ,[name]
           ,[createdate]
           ,[origin]
           ,[is_paid]
           ,[round_start]
           ,[id_user])
select distinct @season, t.[id]
           ,t.[name]
           ,t.[createdate]
           ,o.name
           ,case when o.id in (1, 10, 11, 12, 70, 71, 90, 100) then 1 else 0 end
           ,r.[order]
           ,[id_user]
from ng_team t with (nolock)
inner join ng_user u1 with (nolock) on u1.id = t.id_user
inner join [ngLigaRecord].[dbo].ng_user u2 with (nolock) on u1.email = u2.email
inner join [ngLigaRecord].[dbo].tpd_user u with (nolock) on u2.id = u.id
inner join ng_team_origin o with (nolock) on o.id = t.id_origin
inner join [ngLigaRecord].[dbo].[tpd_round] r with (nolock) on r.season = @season and t.createdate > r.[start_date] and t.createdate <= r.end_date
inner join ng_team_league_private tlp with (nolock) on tlp.id_team = t.id and tlp.status = 1 and tlp.is_valid = 1
inner join [ngLigaRecord].[dbo].tpd_league l with (nolock) on l.season = @season and l.id = tlp.id_league


GO


